from polls.models import Poll
from django.contrib import admin

admin.site.register(Poll)
