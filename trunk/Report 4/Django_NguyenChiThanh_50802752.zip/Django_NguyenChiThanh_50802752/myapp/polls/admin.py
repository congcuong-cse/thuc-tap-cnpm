from polls.models import Manufacturer, Motorcycle
from django.contrib import admin
admin.site.register(Manufacturer)
admin.site.register(Motorcycle)
