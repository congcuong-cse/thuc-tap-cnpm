from django.db import models

# Create your models here.
class Manufacturer(models.Model):
	name_of_manu = models.CharField(max_length = 100)
	found_date = models.DateField('date founed')
	country = models.CharField(max_length = 50)

class Motorcycle(models.Model):
	name_of_moto = models.CharField(max_length = 100)
	cost = models.IntegerField()
	engine = models.CharField(max_length = 30)
	color = models.CharField(max_length = 30)