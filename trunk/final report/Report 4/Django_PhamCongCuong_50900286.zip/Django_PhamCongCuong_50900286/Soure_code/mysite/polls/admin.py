from polls.models import Poll,Choice
from django.contrib import admin

admin.site.register(Poll)
admin.site.register(Choice)
