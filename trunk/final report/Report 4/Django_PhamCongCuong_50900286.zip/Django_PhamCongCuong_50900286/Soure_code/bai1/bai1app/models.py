from django.db import models

# Create your models here.
class Manufacturer(models.Model): 
    # A manufacturer
    name = models.CharField(max_length=200)
    founding_date = models.DateTimeField('date founded')
    country = models.CharField(max_length=100)
 
class Motorcycle(models.Model): 
    # A type of motorcycle
    name = models.CharField(max_length=200)
    cost = models.IntegerField()
    engine_type = models.CharField(max_length=200)
    color = models.CharField(max_length=200)
