TITLE= (
        ('trang_chu', 'Trang chủ'),
        ('dien_dan', 'Diễn đàn'),
    )