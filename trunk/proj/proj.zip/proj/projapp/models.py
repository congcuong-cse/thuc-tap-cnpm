﻿from django.db import models
from django.contrib.auth.models import User
from django import forms
from django.forms import ModelForm
from django.core.validators import MaxValueValidator,MinValueValidator
from django.utils.translation import ugettext_lazy as _

class GiangVien (models.Model):
    mgv = models.OneToOneField(User, verbose_name='Mã giảng viên');
    ten_gv = models.CharField('Tên giảng viên',max_length=50);
    ngay_sinh = models.DateField('Ngày sinh');
    
    def __unicode__(self):
        return self.mgv.username +":" +self.ten_gv
    
    class Meta:
        verbose_name_plural ='Giảng viên'
    

class SinhVien (models.Model):
    GENDER_CHOICES = (
        ('M', 'Nam'),
        ('F', 'Nữ'),
    )
    NGANH_CHOICES = (
        ('CK',     'Khoa Cơ khí'),
        ('DC',     'Địa chất-Dầu khí'),
        ('DD',     'Điện - Điện tử'),
        ('MT',     'Khoa học và Kỹ thuật Máy tính'),
        ('HC',     'Kỹ thuật Hóa học'),
        ('QL',     'Quản lý Công nghiệp'),
        ('XD',     'Kỹ Thuật Xây dựng'),
        ('MO',     'Môi trường'),
        ('GT',     'Kỹ thuật Giao thông'),
        ('UD',     'Khoa học Ứng dụng'),
        ('VL',     'Công nghệ Vật liệu'),
    )
    mssv =models.OneToOneField(User, verbose_name='Mã số sinh viên');
    ten_sv = models.CharField('Tên sinh viên',max_length=50);
    ngay_sinh = models.DateField('Ngày sinh');
    gioi_tinh = models.CharField ('Giới tính',max_length=1, choices=GENDER_CHOICES);
    khoa = models.IntegerField('Khoá');
    nganh = models.CharField('Ngành',max_length=2, choices=NGANH_CHOICES);
    
    def __unicode__(self):
        return self.mssv.username +':'+self.ten_sv
    
    class Meta:
        verbose_name_plural ='Sinh viên'
    
    
class MonHoc (models.Model):
    mmh = models.CharField('Mã môn học',max_length=6,primary_key=True);
    ten_mh = models.CharField('Tên môn học',max_length=50);
    tile_giuaky = models.FloatField('Tỉ lệ giữa kỳ',default=0.2,validators=[MaxValueValidator(1.0),MinValueValidator(0.0)])
    def tile_cuoiky(self):
        return 1-self.tile_giuaky
    tile_cuoiky.short_description = 'Tỉ lệ cuối kỳ'  
    
    def __unicode__(self):
        return self.mmh +':'+self.ten_mh
    
    class Meta:
        verbose_name_plural ='Môn học'
    
class HocKy (models.Model):
    mhk = models.IntegerField('Mã học kỳ',primary_key=True);
    ten_hk = models.CharField('Tên học kỳ',max_length=50,unique=True);
    
    def __unicode__(self):
        return str(self.mhk)
    
    class Meta:
        verbose_name_plural ='Học kỳ'
    
    
class LopMonHoc (models.Model):
    hoc_ky = models.ForeignKey(HocKy,verbose_name='Học kỳ');
    mon_hoc = models.ForeignKey(MonHoc,verbose_name='Môn học');
    nhom_to = models.CharField('Nhóm tổ',max_length=5);
    giang_vien = models.ForeignKey(GiangVien,verbose_name='Giảng viên',blank=True, null=True);
    
    def __unicode__(self):
        return self.hoc_ky.__unicode__()+' - '+ self.mon_hoc.__unicode__()+' - ' + self.nhom_to
    
    class Meta:
        verbose_name_plural ='Lớp môn học'
        unique_together =('hoc_ky','mon_hoc','nhom_to')
    
class DanhSachDiem(models.Model):
    mlmh = models.ForeignKey(LopMonHoc,verbose_name='Học kỳ-Môn học-Nhóm');
    mssv = models.ForeignKey(SinhVien,verbose_name='Sinh viên');
    diem_giua_ky = models.FloatField('Điểm giữa kỳ',blank=True, null=True, validators=[MaxValueValidator(10.0),MinValueValidator(0.0)]);
    diem_cuoi_ky = models.FloatField('Điểm cuối kỳ',blank=True, null=True, validators=[MaxValueValidator(10.0),MinValueValidator(0.0)]);
    diem_tong_ket = models.FloatField('Điểm tổng kết',blank=True, null=True, validators=[MaxValueValidator(10.0),MinValueValidator(0.0)]);
    
    def diem_tong_ket(self):
        if(self.diem_giua_ky is not None and self.diem_cuoi_ky is not None):
            lmh=LopMonHoc.objects.select_related().get(pk=self.mlmh_id)
            mh=MonHoc.objects.select_related().get(pk=lmh.mon_hoc_id)

            return self.diem_giua_ky*mh.tile_giuaky + self.diem_cuoi_ky*mh.tile_cuoiky()
        else:
            return None
    diem_tong_ket.short_description = 'Điểm tổng kết'    
    
    
    def __unicode__(self):
        return ''
        
    class Meta:
        verbose_name_plural = 'Danh sách sinh viên và điểm'
        unique_together =('mlmh','mssv')



#Forms
class DanhSachDiemForm(ModelForm):
    class Meta:
        model = DanhSachDiem
    