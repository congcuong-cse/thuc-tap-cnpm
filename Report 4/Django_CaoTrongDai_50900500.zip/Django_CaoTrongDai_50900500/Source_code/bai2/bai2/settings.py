EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'youremail@gmail.com' #email
EMAIL_HOST_PASSWORD = 'yourpasswords'   #password
EMAIL_PORT = 587
