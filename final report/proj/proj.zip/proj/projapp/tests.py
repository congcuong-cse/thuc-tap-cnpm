﻿"""
This file demonstrates writing tests using the unittest module. These will pass
when you run "manage.py test".

Replace this with more appropriate tests for your application.
"""

from django.test import TestCase
from django.test.client import Client
from django.contrib.auth.models import User,Group
from django.contrib.sites.models import Site

from projapp.models import *
from projapp.models import *


class ModelTest(TestCase):
    def test_giangvien_creation(self):
        new_user = User.objects.create_user('GV0001', 'GV0001@giangvien.com', 'giangvien')
        gv = GiangVien.objects.create(mgv=new_user,ten_gv='ĐINH BÁC ÁI',ngay_sinh='1989-01-10')
        self.assertEqual(GiangVien.objects.count(), 1)
        self.assertEqual(gv.mgv.id, new_user.id)
        self.assertEqual(unicode(gv),
                         "GV0001:ĐINH BÁC ÁI")
        
    def test_sinhvien_creation(self):
        new_user = User.objects.create_user('20108018', '20108018@sinhvien.com', 'sinhvien')
        self.assertRaises(SinhVien.objects.create, mssv=new_user,ten_sv='TẠ VĂN HUYNH',ngay_sinh='1989-12-25',gioi_tinh='B',khoa='2001',nganh='CK')
        self.assertRaises(SinhVien.objects.create, mssv=new_user,ten_sv='TẠ VĂN HUYNH',ngay_sinh='1989-12-25',gioi_tinh='M',khoa='2001',nganh='II')
        sv = SinhVien.objects.create(mssv=new_user,ten_sv='TẠ VĂN HUYNH',ngay_sinh='1989-12-25',gioi_tinh='M',khoa='2001',nganh='CK')
        self.assertEqual(SinhVien.objects.count(), 1)
        self.assertEqual(sv.mssv.id, new_user.id)
        self.assertEqual(unicode(sv),
                         "20108018:TẠ VĂN HUYNH")
        
    def test_monhoc_creation(self):
        mh=MonHoc.objects.create(mmh='003003',ten_mh='Anh văn 3')
        self.assertEqual(MonHoc.objects.count(), 1)
        self.assertEqual(unicode(mh),
                         "003003:Anh văn 3")
        
    def test_hocky_creation(self):
        hk=HocKy.objects.create(mhk='102',ten_hk='HK 2 (2010-2011)')
        self.assertEqual(HocKy.objects.count(), 1)
        self.assertEqual(unicode(hk),
                         "102")
    
    def test_lopmonhoc_creation(self):
        new_user = User.objects.create_user('GV0001', 'GV0001@giangvien.com', 'giangvien')
        gv = GiangVien.objects.create(mgv=new_user,ten_gv='ĐINH BÁC ÁI',ngay_sinh='1989-01-10')
        mh=MonHoc.objects.create(mmh='003003',ten_mh='Anh văn 3')
        hk=HocKy.objects.create(mhk='102',ten_hk='HK 2 (2010-2011)')
        lmh=LopMonHoc.objects.create(hoc_ky=hk,mon_hoc=mh,nhom_to='A',giang_vien=gv)
        self.assertEqual(LopMonHoc.objects.count(), 1)
        self.assertEqual(unicode(lmh),
                         "102 - 003003:Anh văn 3 - A")
    
    def test_danhsachdiem_creation(self):
        new_user = User.objects.create_user('GV0001', 'GV0001@giangvien.com', 'giangvien')
        gv = GiangVien.objects.create(mgv=new_user,ten_gv='ĐINH BÁC ÁI',ngay_sinh='1989-01-10')
        new_user = User.objects.create_user('20108018', '20108018@sinhvien.com', 'sinhvien')
        sv = SinhVien.objects.create(mssv=new_user,ten_sv='TẠ VĂN HUYNH',ngay_sinh='1989-12-25',gioi_tinh='M',khoa='2001',nganh='CK')
        mh=MonHoc.objects.create(mmh='003003',ten_mh='Anh văn 3')
        hk=HocKy.objects.create(mhk='102',ten_hk='HK 2 (2010-2011)')
        lmh=LopMonHoc.objects.create(hoc_ky=hk,mon_hoc=mh,nhom_to='A',giang_vien=gv)
        self.assertRaises(DanhSachDiem.objects.create, mlmh=lmh,mssv=sv,diem_giua_ky=11,diem_cuoi_ky =8)
        self.assertRaises(DanhSachDiem.objects.create, mlmh=lmh,mssv=sv,diem_giua_ky=-1,diem_cuoi_ky =8)
        self.assertRaises(DanhSachDiem.objects.create, mlmh=lmh,mssv=sv,diem_giua_ky=11,diem_cuoi_ky =-0.1)
        self.assertRaises(DanhSachDiem.objects.create, mlmh=lmh,mssv=sv,diem_giua_ky=11,diem_cuoi_ky =10.1)
        dsd=DanhSachDiem.objects.create(mlmh=lmh,mssv=sv,diem_giua_ky=8,diem_cuoi_ky =8)
        self.assertEqual(DanhSachDiem.objects.count(), 1)
        self.assertEqual(unicode(dsd),'')
        self.assertEqual(dsd.diem_tong_ket(),8)
    
    def test_giangvien_unique(self):
        new_user = User.objects.create_user('GV0001', 'GV0001@giangvien.com', 'giangvien')
        gv1 = GiangVien.objects.create(mgv=new_user,ten_gv='ĐINH BÁC ÁI',ngay_sinh='1989-01-10')
        self.assertRaises(GiangVien.objects.create,mgv=new_user,ten_gv='ALICE',ngay_sinh='1984-01-10')
    
    def test_sinhvien_unique(self):
        new_user = User.objects.create_user('20108018', '20108018@sinhvien.com', 'sinhvien')
        sv = SinhVien.objects.create(mssv=new_user,ten_sv='TẠ VĂN HUYNH',ngay_sinh='1989-12-25',gioi_tinh='M',khoa='2001',nganh='CK')
        self.assertRaises(SinhVien.objects.create,mssv=new_user,ten_sv='BOB',ngay_sinh='1983-12-25',gioi_tinh='M',khoa='2001',nganh='MT')
    
    def test_monhoc_unique(self):
        mh=MonHoc.objects.create(mmh='003003',ten_mh='Anh văn 3')
        self.assertRaises(SinhVien.objects.create,mmh='003003',ten_mh='Anh văn 2')
    
    def test_lopmonhoc_unique(self):
        new_user = User.objects.create_user('GV0001', 'GV0001@giangvien.com', 'giangvien')
        gv = GiangVien.objects.create(mgv=new_user,ten_gv='ĐINH BÁC ÁI',ngay_sinh='1989-01-10')
        mh1=MonHoc.objects.create(mmh='003003',ten_mh='Anh văn 3')
        mh2=MonHoc.objects.create(mmh='003002',ten_mh='Anh văn 2')
        hk1=HocKy.objects.create(mhk='102',ten_hk='HK 2 (2010-2011)')
        hk2=HocKy.objects.create(mhk='111',ten_hk='HK 1 (2011-2012)')
        lmh1=LopMonHoc.objects.create(hoc_ky=hk1,mon_hoc=mh1,nhom_to='A',giang_vien=gv)
        lmh2=LopMonHoc.objects.create(hoc_ky=hk1,mon_hoc=mh1,nhom_to='B',giang_vien=gv)
        lmh3=LopMonHoc.objects.create(hoc_ky=hk2,mon_hoc=mh1,nhom_to='B',giang_vien=gv)
        lmh4=LopMonHoc.objects.create(hoc_ky=hk2,mon_hoc=mh2,nhom_to='B',giang_vien=gv)        
        self.assertEqual(LopMonHoc.objects.count(), 4)
        self.assertRaises(LopMonHoc.objects.create, hoc_ky=hk1,mon_hoc=mh1,nhom_to='A',giang_vien=gv)
    
    def test_danhsanhdiem_unique(self):
        new_user = User.objects.create_user('GV0001', 'GV0001@giangvien.com', 'giangvien')
        gv = GiangVien.objects.create(mgv=new_user,ten_gv='ĐINH BÁC ÁI',ngay_sinh='1989-01-10')
        new_user = User.objects.create_user('20108018', '20108018@sinhvien.com', 'sinhvien')
        sv1 = SinhVien.objects.create(mssv=new_user,ten_sv='TẠ VĂN HUYNH',ngay_sinh='1989-12-25',gioi_tinh='M',khoa='2001',nganh='CK')
        new_user = User.objects.create_user('20108017', '20108017@sinhvien.com', 'sinhvien')
        sv2 = SinhVien.objects.create(mssv=new_user,ten_sv='Sue',ngay_sinh='1989-12-25',gioi_tinh='F',khoa='2001',nganh='CK')
        mh=MonHoc.objects.create(mmh='003003',ten_mh='Anh văn 3')
        hk=HocKy.objects.create(mhk='102',ten_hk='HK 2 (2010-2011)')
        lmh1=LopMonHoc.objects.create(hoc_ky=hk,mon_hoc=mh,nhom_to='A',giang_vien=gv)
        dsd1=DanhSachDiem.objects.create(mlmh=lmh1,mssv=sv1,diem_giua_ky=8,diem_cuoi_ky =8)
        dsd2=DanhSachDiem.objects.create(mlmh=lmh1,mssv=sv2)
        self.assertEqual(DanhSachDiem.objects.count(), 2)
        self.assertRaises(DanhSachDiem.objects.create,mlmh=lmh1,mssv=sv1)
        
class ViewTest(TestCase):
    def setUp(self):
        # Every test needs a client.
        self.client = Client()
        new_user = User.objects.create_user('20108018', '20108018@sinhvien.com', 'sinhvien')
        self.sv = SinhVien.objects.create(mssv=new_user,ten_sv='TẠ VĂN HUYNH',ngay_sinh='1989-12-25',gioi_tinh='M',khoa='2001',nganh='CK')
        new_user = User.objects.create_user('GV0001', 'GV0001@giangvien.com', 'giangvien')
        self.gv = GiangVien.objects.create(mgv=new_user,ten_gv='ĐINH BÁC ÁI',ngay_sinh='1989-01-10')
    
    def test_index(self):
        # Issue a GET request.
        response = self.client.get('/home/')

        # Check that the response is 200 OK.
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                'projapp/index.html') 
    def test_xemdiem(self):
        response = self.client.get('/home/xemdiem/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/xemdiem.html') 
    def test_ketqua(self):
        response = self.client.get('/home/ketqua/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/ketqua.html')
    def test_sinhvien(self):
        self.client.login(username='20108018', password='sinhvien')
        response = self.client.get('/home/sinhvien/',{'sinhvien':self.sv})
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/sinhvien.html')
         
    def test_sinhvien_error(self):
        self.client.login(username='GV0001', password='giangvien')
        response = self.client.get('/home/sinhvien/')
        self.assertEqual(response.context['messenge'], "You are not a student.")
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/error.html') 
    
    def test_giangvien(self):
        self.client.login(username='GV0001', password='giangvien')
        response = self.client.get('/home/giangvien/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/giangvien.html') 
        
    def test_giangvien_error(self):
        self.client.login(username='20108018', password='sinhvien')
        response = self.client.get('/home/giangvien/')
        self.assertEqual(response.context['messenge'], "You are not the teacher.")
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/error.html')  
    def test_diemsinhvien(self):
        self.client.login(username='20108018', password='sinhvien')
        response = self.client.get('/home/sinhvien/diemsinhvien/',{'sinhvien':self.sv})
        self.assertEqual(response.status_code, 200)
        hoc_ky_list = HocKy.objects.all().order_by("-mhk")
        response = self.client.get('/home/sinhvien/diemsinhvien/',{'hoc_ky_list':hoc_ky_list})
        self.assertEqual(response.context['messenge'], "No term in the database.")
        self.assertTemplateUsed(response,
                                   'projapp/diemsinhvien.html')
        
    def test_ketqua_diemsinhvien(self):
        self.client.login(username='20108018', password='sinhvien')
        response = self.client.get('/home/sinhvien/diemsinhvien/ketqua/',{'sinhvien':self.sv})
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/ketqua_diemsinhvien.html')
    
    def test_diemlop(self):
        self.client.login(username='GV0001', password='giangvien')
        response = self.client.get('/home/giangvien/diemlop/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/diemlop.html') 
    
    def test_ketqua_diemlop(self):
        self.client.login(username='GV0001', password='giangvien')
        mh=MonHoc.objects.create(mmh='003003',ten_mh='Anh văn 3')
        hk=HocKy.objects.create(mhk='102',ten_hk='HK 2 (2010-2011)')
        lop_hoc=LopMonHoc.objects.create(hoc_ky=hk,mon_hoc=mh,nhom_to='A',giang_vien=self.gv)
        response = self.client.get('/home/giangvien/diemlop/ketqua/',{'lop_hoc':lop_hoc.pk})
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                   'projapp/ketqua_diemlop.html') 
    
