from django.test import TestCase
from django.test.client import Client
from django.contrib.auth.models import User
from django.contrib.sites.models import Site

from forum.models import *

class ModelTest(TestCase):
    def test_forum_creation(self):
        forum = Forum.objects.create(title='forum1')
        self.assertEqual(Forum.objects.count(), 1)
        self.assertEqual(unicode(forum),'forum1')
        self.assertEqual(forum.num_posts(),0)
        self.assertEqual(forum.last_post(),None)
        
    def test_thread_creation(self):
        new_user = User.objects.create_user('bob', 'bob@test.com', 'test')
        forum = Forum.objects.create(title='forum1')
        thread = Thread.objects.create(title='thread1',creator=new_user,forum=forum)
        self.assertEqual(Thread.objects.count(), 1)
        self.assertEqual(unicode(thread),'bob - thread1')
        self.assertEqual(thread.num_posts(),0)
        self.assertEqual(thread.num_replies(),-1)
        self.assertEqual(thread.last_post(),None)
        
    def test_post_creation(self):
        new_user = User.objects.create_user('bob', 'bob@test.com', 'test')
        forum = Forum.objects.create(title='forum1')
        thread = Thread.objects.create(title='thread1',creator=new_user,forum=forum)
        post = Post.objects.create(title='post1',creator=new_user,thread=thread,body='body')
        self.assertEqual(Post.objects.count(), 1)
        self.assertEqual(unicode(post),'bob - bob - thread1 - post1')
        self.assertEqual(post.short(), u"%s - %s\n%s" % ('bob', 'post1', post.created.strftime("%b %d, %I:%M %p")))
        
    def test_user_profile_creation(self):
        new_user = User.objects.create_user('bob', 'bob@test.com', 'test')
        user_profile = UserProfile.objects.get(user=new_user)
        self.assertEqual(UserProfile.objects.count(), 1)
        self.assertEqual(unicode(user_profile),'bob')

class ViewTest(TestCase):
    def setUp(self):
        f = Forum.objects.create(title="forum")
        u = User.objects.create_user("ak", "ak@abc.org", "pwd")
        Site.objects.create(domain="test.org", name="test.org")
        t = Thread.objects.create(title="thread", creator=u, forum=f)
        p = Post.objects.create(title="post", body="body", creator=u, thread=t)
        
    def test_main(self):
        response = self.client.get('/forum/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                'forum/list.html')
        
    def test_forum(self):
        response = self.client.get('/forum/forum/1/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                'forum/forum.html')
        response = self.client.get('/forum/forum/1/?page=2')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response,
                                'forum/forum.html')
        
class SimpleTest(TestCase):
    def setUp(self):
        f = Forum.objects.create(title="forum")
        u = User.objects.create_user("ak", "ak@abc.org", "pwd")
        Site.objects.create(domain="test.org", name="test.org")
        t = Thread.objects.create(title="thread", creator=u, forum=f)
        p = Post.objects.create(title="post", body="body", creator=u, thread=t)

    def content_test(self, url, values):
        """Get content of url and test that each of items in `values` list is present."""
        r = self.c.get(url)
        self.assertEquals(r.status_code, 200)
        for v in values:
            self.assertTrue(v in r.content)
