from django.db import models

# Create your models here.
class Manufacturer(models.Model):
    manuname = models.CharField(max_length = 200 )
    found_date = models.DateField('date founded')
    country = models.CharField(max_length = 50)
    
    
class Motorcycle(models.Model):
    motorname = models.CharField(max_length = 200)
    cost = models.IntegerField()
    engine = models.CharField(max_length = 50)
    color = models.CharField(max_length = 50)
    


